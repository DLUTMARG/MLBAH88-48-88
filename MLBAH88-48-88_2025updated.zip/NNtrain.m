clc,clear
%% Import data
load('Database\traindata.mat'); 
dataset = traindata;
test_data_num = randperm(size(dataset,1)); 
test_data_num = test_data_num(1:round(size(dataset,1)/10))';
train_data_num = setdiff([1:size(dataset,1)]',test_data_num);
object_num = 6; inp = dataset(:,1:5); outp = dataset(:,object_num);
%% Normalise the data set
[inp_i,ps_i] = mapminmax(inp(train_data_num,:)',0,1);
[outp_t,ps_t] = mapminmax(outp(train_data_num,:)',0,1);
%% Build a neural network
% 'trainlm' is usually fastest.
% 'trainbr' takes longer but may be better for challenging problems.
% 'trainscg' uses less memory. Suitable in low memory situations.
trainFcn = 'trainlm';  % Levenberg-Marquardt backpropagation.
hiddenLayerSize = [40 40 30 10]; % Set the neuron number of each layer of the network
net = feedforwardnet(hiddenLayerSize,trainFcn);
% Choose your suitable activation function, such as 'tansig' 'purelin' 'relu' 'leakyrelu' 'softmax' and so on.
net.layers{1}.transferFcn = 'logsig'; net.layers{2}.transferFcn = 'logsig';
net.layers{3}.transferFcn = 'logsig'; net.layers{4}.transferFcn = 'logsig';
%% Setup Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 20/100;
net.divideParam.testRatio = 10/100;
%% Train the Network
[net,tr] = train(net,inp_i,outp_t);
% save('ps_i','ps_i'); save('ps_t','ps_t'); save('net','net'); 
%% Test the Network
x_test = mapminmax('apply',inp(test_data_num,:)',ps_i);
y_test = net(x_test);
yout = mapminmax('reverse',y_test,ps_t);
x_outp = mapminmax('apply',outp(test_data_num,:)',ps_t);
e = gsubtract(x_outp,y_test);
rmse = sqrt((1/size(e,2))*sum(e.^2));
mer = max(abs((outp(test_data_num,:)'-yout)./outp(test_data_num,:)'));
% View the construction of the Network
% view(net)
%% Plot the training results
X = x_outp; Y = y_test;
plot([X],[Y],'o','color',[253 192 78]./255);
hold on
plot([Y],[Y],'linewidth',2,'color',[102 147 72]./255);
hold off
set(gca,'YLim',[min(Y) max(Y)]); set(gca,'XLim',[min(Y) max(Y)]);
set(gca,'YTick',[min(Y) max(Y)]); set(gca,'XTick',[min(Y) max(Y)]); set(gca,'FontSize',20);
h1 = legend('Data','Fit');
set(h1,'Location','NorthWest','Box','off','FontSize',15);
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
%  Please feel free to contact us with any questions! 
%  - Chuang Ma, Dalian University of Technology
%  - Yichao Zhu, Dalian University of Technology
%  - Xu Guo, Dalian University of Technology
%  - chuangma@mail.dlut.edu.cn / yichaozhu@dlut.edu.cn / guoxu@dlut.edu.cn
%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%